
export const Pid = 0

export const RccTokenContract = '0x6FCE5Dd421c88B7df4552E037362Bcea35Ae0AcB'
export const RccStakeContract = '0x01A01E8B862F10a3907D0fC7f47eBF5d34190341'