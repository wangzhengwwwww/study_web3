import { getDefaultConfig } from '@rainbow-me/rainbowkit';
import {
  mainnet,
  optimism,
  polygon,
  sepolia,
} from 'wagmi/chains';
console.log(process.env.WalletConnectId)
export const config = getDefaultConfig({
  appName: 'RainbowKit App',
  projectId: '94066ab3be2718981f226c7407038ba4',
  chains: [
    mainnet,
    sepolia,
  ],
  ssr: true,
});